library(MASS,lib.loc = "/home/xug3/R_libs")
library(nleqslv,lib.loc = "/home/xug3/R_libs")
library(lme4,lib.loc = "/home/xug3/R_libs")
library(nlme,lib.loc = "/home/xug3/R_libs")
library(geepack,lib.loc = "/home/xug3/R_libs")
library(mvtnorm,lib.loc = "/home/xug3/R_libs")
library(data.table,lib.loc = "/home/xug3/R_libs")
library(plyr,lib.loc = "/home/xug3/R_libs")
library(expm,lib.loc = "/home/xug3/R_libs")
library(CompQuadForm,lib.loc = "/home/xug3/R_libs")
library(LBRAT,lib.loc = "/home/xug3/R_libs")
library(RVMMAT,lib.loc = "/home/xug3/R_libs")
library(foreach,lib.loc = "/home/xug3/R_libs")
library(iterators,lib.loc = "/home/xug3/R_libs")
library(doParallel,lib.loc = "/home/xug3/R_libs")
library(rootSolve,lib.loc="/home/xug3/R_libs")
library(weightedScores,lib.loc="/home/xug3/R_libs")



registerDoParallel(10)
nsimulation=1000;
nsnp=1000

type1error=function(){
  simudata=rvmmat_simu(n.sample=2000,n.time=5,snp.count=nsnp,phe.model="liability",oversampling="baseline")
  y.long=simudata$phe.long
  time=simudata$phe.time
  y.cov=simudata$phe.cov.long
 phe.model=simudata$phe.model
 
  G=simudata$snp.mat
G=G[,1:nsnp]
   rvmmat.est=rvmmat_est(y.long,time,y.cov,phe.model)
  RVMMATp=rvmmat_test(rvmmat.est,G)
return(RVMMATp)
}

oper = foreach(i = 1:nsimulation,.combine = "rbind") %dopar%{
 type1error()
  
}
type1result= as.data.frame(oper)

write.table(type1result,"type1result.txt",row.names = FALSE)
q("no")