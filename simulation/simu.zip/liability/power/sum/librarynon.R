library(MASS,lib.loc = "/home/xug3/R_libs")
library(nleqslv,lib.loc = "/home/xug3/R_libs")
library(lme4,lib.loc = "/home/xug3/R_libs")
library(nlme,lib.loc = "/home/xug3/R_libs")
library(geepack,lib.loc = "/home/xug3/R_libs")
library(mvtnorm,lib.loc = "/home/xug3/R_libs")
library(data.table,lib.loc = "/home/xug3/R_libs")
library(plyr,lib.loc = "/home/xug3/R_libs")
library(expm,lib.loc = "/home/xug3/R_libs")
library(CompQuadForm,lib.loc = "/home/xug3/R_libs")
library(LBRAT,lib.loc = "/home/xug3/R_libs")
library(RVMMAT,lib.loc = "/home/xug3/R_libs")
library(foreach,lib.loc = "/home/xug3/R_libs")
library(iterators,lib.loc = "/home/xug3/R_libs")
library(doParallel,lib.loc = "/home/xug3/R_libs")
library(rootSolve,lib.loc="/home/xug3/R_libs")
library(weightedScores,lib.loc="/home/xug3/R_libs")



registerDoParallel(10)
nsimulation=1000;
aca.pvalue  <- function(pvalue, weights){
  rm.idx = which(is.na(pvalue)|pvalue>(1-10^-5));
  if(length(rm.idx)>0){
  pvalue = pvalue[-rm.idx]; weights = weights[-rm.idx]}
  T_aca <- c(weights^2)%*%tan((0.5-pvalue)*pi)
  p.aca = 0.5-atan(T_aca/sum(weights^2))/pi
}


type1error=function(){
  simudata=rvmmat_simu(n.sample=2000,n.time=5,genetic.effect=0.6,snp.count=4,phe.model="liability",oversampling="sum")
  y.long=simudata$phe.long
  time=simudata$phe.time
  y.cov=simudata$phe.cov.long
 phe.model=simudata$phe.model
 
   lbrat.est0=glmm_est(y.long,time,y.cov,phe.model)
  G=simudata$snp.mat
 LBRATp=lbrat_test(lbrat.est0, G)[6,]
  G=G[,6]
   rvmmat.est=rvmmat_est(y.long,time,y.cov,phe.model)
  RVMMATp=rvmmat_test(rvmmat.est,G)

    cluster.id<-unique(time[,1]);m<-length(cluster.id);N=length(y.long);knots=unique(time[,2]);ntime=length(knots)
    center.G<-as.matrix(G-mean(G))
    var_g<-t(center.G)%*%(center.G)/(m-1);
    maf<-min(mean(G)/2, 1-mean(G)/2);
    G1<-as.matrix(center.G[match(time[,1],cluster.id),1])
    inciN=matrix(rep(0,ntime*N),ncol=ntime)
    for(i in 1:N) inciN[i,which(knots==time[i,2])]=1
    inciNG=inciN*c(G1)
    alldata=data.frame(cbind(y.long,inciNG,y.cov,time))
    colnames(alldata)=c("y","G1","G2","G3","G4","G5","X1","X2","id","time")
        xdat=as.matrix(cbind(1,alldata[,2:7]));ydat=alldata$y;id=alldata$id;tvec=alldata$time
    out<-wtsc.wrapper(xdat,ydat,id,tvec,margmodel="bernoulli",link="logit",corstr="ar")
       se <- sqrt(diag(out$asympcov))
   copulaall=pchisq((out$WSest/se)^2,1,lower.tail=F)[2:6]
   copula=aca.pvalue(copulaall,rep(0.2,5))
 result=cbind(LBRATp[3:4], RVMMATp,copula)
return(result)
}


oper = foreach(i = 1:nsimulation,.combine = "rbind") %dopar%{
 type1error()
  
}
type1result= as.data.frame(oper)

write.table(type1result,"type1result.txt",row.names = FALSE)
q("no")